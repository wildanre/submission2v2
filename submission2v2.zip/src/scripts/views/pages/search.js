import { searchRestaurant } from '../../data/restaurant-api';

const Search = {
  async render() {
    const queryParams = new URLSearchParams(window.location.hash.slice(1).split('?')[1]);
    const query = queryParams.get('q') || '';

    return `
      <div class="search-content">
        <h2>Search for Restaurants</h2>
        <div class="search-input">
          <input type="text" id="searchInput" placeholder="Search for restaurants..." value="${query}">
          <button id="searchBtn">Search</button>
        </div>
        <div id="searchResults" class="search-results"></div> <!-- Hasil pencarian -->
      </div>
    `;
  },

  async afterRender() {
    const searchInput = document.getElementById('searchInput');
    const searchBtn = document.getElementById('searchBtn');
    const searchResults = document.getElementById('searchResults');
    const queryParams = new URLSearchParams(window.location.hash.slice(1).split('?')[1]);
    const query = queryParams.get('q') || '';

    if (query) {
      searchInput.value = query;
      await handleSearch(query);  // Jika ada query, lakukan pencarian langsung
    }

    const handleSearch = async (searchTerm) => {
      if (searchTerm === '') return;

      showLoading();
      try {
        const results = await searchRestaurant(searchTerm);
        const restaurants = results.restaurants || [];

        // Tampilkan hasil pencarian jika ada restoran
        if (restaurants.length > 0) {
          searchResults.style.display = 'block';  // Menampilkan hasil pencarian
          searchResults.innerHTML = restaurants.map(restaurant => `
            <div class="restaurant-item">
              <img src="https://restaurant-api.dicoding.dev/images/medium/${restaurant.pictureId}" alt="${restaurant.name}" class="restaurant-img">
              <div class="restaurant-item-content">
                <h3>${restaurant.name}</h3>
                <p>${restaurant.city}</p>
                <p class="restaurant-description">${restaurant.description.substring(0, 100)}...</p> <!-- Batasi deskripsi -->
                <p class="restaurant-rating">Rating: ${restaurant.rating}</p>
              </div>
            </div>
          `).join('');
        } else {
          searchResults.innerHTML = '<p>No results found</p>';
          searchResults.style.display = 'block';  // Menampilkan hasil meskipun kosong
        }
      } catch (error) {
        console.error('Error searching for restaurants:', error);
        searchResults.innerHTML = '<p>No results found</p>';
        searchResults.style.display = 'block';  // Menampilkan hasil meskipun terjadi error
      } finally {
        hideLoading();
      }
    };

    // Event listener untuk pencarian
    searchBtn.addEventListener('click', () => {
      const query = searchInput.value.trim();
      if (query) {
        window.location.hash = `#/search?q=${query}`;
        handleSearch(query);
      }
    });

    // Event listener untuk pencarian dengan tombol Enter
    searchInput.addEventListener('keyup', (event) => {
      if (event.key === 'Enter') {
        const query = searchInput.value.trim();
        if (query) {
          window.location.hash = `#/search?q=${query}`;
          handleSearch(query);
        }
      }
    });
  }
};

// Pastikan showLoading dan hideLoading didefinisikan sebelumnya
const showLoading = () => {
  document.body.classList.add('loading');
};

const hideLoading = () => {
  document.body.classList.remove('loading');
};

export default Search;
