import './nav-bar.js';
import './hero-section.js'; 
import './recommendation-item.js';
import './content-item.js';
import './foot-bar.js';